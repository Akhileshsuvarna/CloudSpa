import 'package:cloud_spa/screens/therapist/auth/sign_in.dart';
import 'package:cloud_spa/screens/therapist/auth/signup.dart';
import 'package:cloud_spa/screens/user/user_auth/signup.dart';
import 'package:flutter/material.dart';

import 'package:cloud_spa/widgets/green_user_button.dart';

class GetStarted extends StatefulWidget {
  @override
  _GetStartedState createState() => _GetStartedState();
}

class _GetStartedState extends State<GetStarted> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                width: MediaQuery.of(context).size.width / 1,
                height: MediaQuery.of(context).size.height / 1.7,
                // child: Image.asset('assets/images/getstarted.jpg'),
                decoration: BoxDecoration(
                  color: Colors.white,
                  image: DecorationImage(
                      image: AssetImage('assets/images/getstarted.jpg'),
                      fit: BoxFit.fill),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Container(
                  alignment: Alignment.topLeft,
                  padding: EdgeInsets.symmetric(horizontal: 15.0),
                  child: Text(
                    'Welcome to\nCloud SPA',
                    style: TextStyle(
                        color: Color(0xFF313D56),
                        fontSize: 35,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ),
              Container(
                alignment: Alignment.topLeft,
                padding: EdgeInsets.symmetric(horizontal: 25.0, vertical: 8.0),
                child: Text(
                  'Personalized spa experience for you',
                  style: TextStyle(
                      color: Color(0xFF313D56),
                      fontSize: 16,
                      fontWeight: FontWeight.w400),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 25.0, vertical: 15.0),
                child: GreenUserButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => UserSignUp(),
                        ));
                  },
                  label: 'Get Started',
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SignUpPage(),
                      ));
                },
                child: Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.only(bottom: 50.0),
                  child: GradientText(
                    'or join us as Therapist',
                    gradient: LinearGradient(colors: [
                      Color(0XFFF96289),
                      Color(0XFF3F5EFB),
                    ]),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GradientText extends StatelessWidget {
  GradientText(
    this.text, {
    @required this.gradient,
  });

  final String text;
  final Gradient gradient;

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      shaderCallback: (bounds) => gradient.createShader(
        Rect.fromLTWH(0, 0, bounds.width, bounds.height),
      ),
      child: Text(
        text,
        style: TextStyle(
          // The color must be set to white for this to work
          color: Colors.white,
          fontSize: 18,
        ),
      ),
    );
  }
}
