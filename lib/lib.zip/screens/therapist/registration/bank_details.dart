import 'package:cloud_spa/screens/therapist/home/home_page.dart';
import 'package:cloud_spa/screens/user/home/home.dart';
import 'package:cloud_spa/screens/user/home/home_page.dart';
import 'package:cloud_spa/widgets/cloud_spa_scaffold.dart';
import 'package:cloud_spa/widgets/gradient_button.dart';
import 'package:cloud_spa/widgets/textfield.dart';
import 'package:flutter/material.dart';

class BankDetails extends StatefulWidget {
  @override
  _BankDetailsState createState() => _BankDetailsState();
}

class _BankDetailsState extends State<BankDetails> {
  TextEditingController bank = new TextEditingController();
  TextEditingController branch = new TextEditingController();
  TextEditingController accountType = new TextEditingController();
  TextEditingController accountHolder = new TextEditingController();
  TextEditingController accountNumber = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return CloudSpaScaffold(
      action: [
        Padding(
          padding: const EdgeInsets.only(right: 10.0),
          child: Center(
            child: Row(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width / 5,
                  child: LinearProgressIndicator(
                    value: 0.75,
                    backgroundColor: Colors.grey,

                  ),
                ),
                SizedBox(
                  width: 8,
                ),
                Text(
                  '2/4',
                  style: TextStyle(color: Color(0xFFF96289)),
                ),
              ],
            ),
          ),
        )
      ],
      isback: true,
      title: '',
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            children: [
              Text(
                'Bank Details',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
              ),
              SizedBox(
                height: 16,
              ),
              Text(
                'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 56,
              ),
              LabeledTextField(
                controller: bank,
                label: 'Bank',
                suffix: true,
                suffixIcon: Icon(Icons.keyboard_arrow_down_rounded),
                hintText: 'Select Bank',
              ),
              SizedBox(
                height: 24,
              ),
              LabeledTextField(
                controller: branch,
                label: 'Branch Name',
                suffix: true,
                suffixIcon: Icon(Icons.keyboard_arrow_down_rounded),
                hintText: 'Select Branch Name',
              ),
              SizedBox(
                height: 24,
              ),
              LabeledTextField(
                controller: accountType,
                label: 'Account Type',
                suffix: true,
                suffixIcon: Icon(Icons.keyboard_arrow_down_rounded),
                hintText: 'Select Account Type',
              ),
              SizedBox(
                height: 24,
              ),
              LabeledTextField(
                controller: accountHolder,
                label: 'Account Holder Name',
                suffix: false,
                hintText: 'Enter Account Holder Name',
              ),
              SizedBox(
                height: 24,
              ),
              LabeledTextField(
                controller: accountNumber,
                label: 'Account Number',
                suffix: false,
                suffixIcon: Icon(Icons.calendar_today_outlined),
                hintText: 'Enter Account Number',
              ),
              SizedBox(
                height: 24,
              ),
              GradientButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
//                        builder: (context) => Home(),
                        builder: (context) => HomePage(),
                      ));
                },
                label: 'Next',
              ),
              SizedBox(
                height: 36,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
