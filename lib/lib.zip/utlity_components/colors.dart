import 'package:flutter/cupertino.dart';

class colors {
  static final bagroundColor = Color(0xFFE5E5E5);
  static final dividercolor = Color(0xFFD6D8DD);
}
