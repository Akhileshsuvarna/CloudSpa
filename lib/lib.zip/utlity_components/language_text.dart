class Texts {
//app bar
  static final String back = 'Back';

//signup
  static final String signup = 'Sign up';
  static final String signupDescription =
      'Lorem Ipsum is simply dummy text of the printing and typesetting industry.';
  static final String mailAddress = 'Mail Address';
  static final String phoneNumber = 'Phone number';
  static final String password = 'Password';
  static final String confirmPassword = 'Confirm Password';
  static final String mailAddressHint = 'Enter Mail Address';
  static final String phoneNumberHint = 'Enter Phone number';
  static final String passwordHint = 'Enter Password';
  static final String confirmPasswordHint = 'Re-Enter Confirm Password';
}
